/**
 * Created by shafaqatahmed on 17/06/2016.
 */

var v;
function gear_tran_loss(v) {
    this.v = v;

    return v;
}