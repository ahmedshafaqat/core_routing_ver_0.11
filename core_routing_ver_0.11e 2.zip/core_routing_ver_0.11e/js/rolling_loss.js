/**
 * Created by shafaqatahmed on 17/06/2016.
 */

function bus_drag1(Cd, py, v, A){
//All the test information based on BYD 350 Electric bus

    var Cd1 = 0.6;
    var py1 = 1.2;
    var v1 = 16.67;
    var A1 = 8.16;

    /*
     Cd1 = cd;
     py1 = py;
     v1 = v;
     A1 = A;
     */



    var Fd = Cd1 * py1 * v1 * A1;
    return Fd;

}