/**
 * Created by shafaqatahmed on 16/06/2016.
 */

var s = 144.00;
var w = 0.00;
var first1 = 144.00;
var used = 0.00;

/*
function battery_spec(stored, weight){

this.s = stored;
this.w = weight;
this.first1 = stored;
    //this is need commented out once setting in place
    s=144.00
    first1 = s;
}
*/

function battery_full(){
    return first1;
}


function battery_used(e){
    used = e;

    if (used > 0.00)
    {
        s = s-used;

    }
    return s;
}