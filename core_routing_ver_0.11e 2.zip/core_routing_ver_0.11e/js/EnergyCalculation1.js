
var global_e = 0.00;
var battery_power_left = 144.00



function bus_drag(Cd, py, v, A){
//All the test information based on BYD 350 Electric bus

    var Cd1 = 0.6;
    var py1 = 1.2;
    var v1 = 16.67;
    var A1 = 8.16;

    /*
       Cd1 = cd;
       py1 = py;   
       v1 = v;
       A1 = A; 
     */
    
    
    
    var Fd = Cd1 * py1 * v1 * A1;
    return Fd;

}

var aircon  = function hvac(temp,pax_load) {
    var min_load = 4.00; // in Kw for running the system
    var half_load = 6.50;
    var full_load  = 13.00;
    var temperature = 0.00;
    temperature = temp;


    if(pax_load == 1 ){
        return min_load;
    }
    if(pax_load > 1 && pax < 35 ){
        var load = pax_load * 0.25;
        return;
    }
    if(pax_load < 10 && temperature > 30){
        return half_load;
    }
    if(pax > 35)
    { return full_load;}

    else return min_load;

}


function mechanical_loss(){
var m_loss = 0.00;

    return m_loss;

}





function energy_calculation(s, t){
    
/* f= ma , a = (v^2-u^2)/2.s , 
W = f * s * cos@theda;
 



*/
//Air Con energy

this.s = s;
this.t = t;



var mec_loss = mechanical_loss();

var e3 = (Math.round(mec_loss*100)/100)*(t1);

var e0 = (Math.round(aircon*100)/100)*(t/1000);
    
var e1 = Math.round(((((16.67^2)*13800)/(2*(s)))*(Math.cos(0))*(t1))*100)/100;

var Fd1 = bus_drag(0,0,0,0); 

var t1 = t / 1000;

var e2 = Math.round((Fd1 * s * t1)/3600);

var e = Math.round(((e1 )*100)/3600)/100 ;
/*
window.alert(Fd1);
window.alert(e2);
window.alert(s);
window.alert(t1);
*/
global_e = e;

return e;
}

function energy(){
    
    if(global_e > 0.00){
    return global_e;
    }
    else return 10.00;
}
function battery_start_status(e){
    this.battery_power_left = e;
}

function battery_update(e){
    var spend_energy = 0.00;
    this.spend_energy = e;
    total_left = battery_power_left - spend_energy;

    battery_power_left = total_left;// update

    return battery_power_left;
}

function battery_current_status() {
    return battery_power_left;

}

