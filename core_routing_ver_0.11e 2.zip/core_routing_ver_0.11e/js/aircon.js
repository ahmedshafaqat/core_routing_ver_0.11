/**
 * Created by shafaqatahmed on 17/06/2016.
 */
function hvac(temp,pax_l) {

    var pax_load = pax_l;
    var min_load = 4.00; // in Kw for running the system
    var half_load = 6.50;
    var full_load  = 13.00;
    var temperature = 0.00;
    temperature = temp;


    if(pax_load == 1 ){
        return min_load;
    }
    if(pax_load > 10 && pax < 35 ){
        var load = pax_load * 0.25;
        return load;
    }
    if(pax_load < 10 && temperature > 30){
        return half_load;
    }
    if(pax > 35)
    { return full_load;}

    else return min_load;

}