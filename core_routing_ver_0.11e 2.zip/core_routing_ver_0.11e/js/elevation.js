elevation = [];
elevationPath = [];
data = new Object();
var finalObj = new Object();
output = '';
var newPath = [];
var jsonStringWithElevation = '';
var jsonString = '';
var roadsPath = '';
var distance = 1200;

function getSamples(distance){
	atEvery = 10;
	samples = distance / atEvery;
	return samples;
}

function setData(a) {
	data = a;
}
function getData() {
	return data;
}
function setElevation(a) {
	elevation.push(a);
}
function getElevation() {
	return elevation;
}
function setElevationPath(a) {
	elevationPath.push(a);
}
function getElevationPath() {
	return elevationPath;
}

// reads json file and finds elevation
// stores json data in var data
// stores elevation data in var elevation
$.getJSON('JSON/american_road_trip.json', function load_json(info) {
	var elevator = new google.maps.ElevationService();
	var path = new Object();
	setData(info);
	lat = info.vehicles[0].start_address.lat;
	lon = info.vehicles[0].start_address.lon;
	location = new google.maps.LatLng(lat, lon);
	getElevationforLocation(elevator, location);
	path.lat = lat;
	path.lng = lon;
	path.elevation = getElevation()[0];
	newPath.push(path);
	for (var i = 0; i < info.services.length; i++) {
		var path = new Object();
		var location = [];
		lat = info.services[i].address.lat;
		lon = info.services[i].address.lon;
		location = new google.maps.LatLng(lat, lon);
		getElevationforLocation(elevator, location);
		path.lat = lat;
		path.lng = lon;
		path.elevation = getElevation()[i+1];
		newPath.push(path);
		roadsPath += lat +','+ lon ;
		roadsPath += '|';
	}
	jsonString = JSON.stringify(newPath);
	getElevationforPath(elevator, newPath,getSamples(distance));
	
});
function getElevationforLocation(elevator, location) {
	elevator.getElevationForLocations({
		'locations' : [ location ]
	}, function(results, status) {
		if (status === google.maps.ElevationStatus.OK && results[0]) {
			setElevation(results[0].elevation.toFixed(3));
		}
	});
}

function getElevationforPath(elevator, path,samples) {
	elevator.getElevationAlongPath({
		'path' : path,
		'samples' : samples
	}, function(results, status) {
		if (status === google.maps.ElevationStatus.OK ) {
			for (var i = 0; i < results.length; i++) {
				setElevationPath(results[i].elevation.toFixed(3));
			  }
			
		}
	});
}

function out() {
	info = getData();

	for (var i = 0; i < newPath.length; i++) {
		newPath[i].elevation = Number(getElevation()[i]);
		output += '<ul>'
		output += '<li>' + 'lon:' + newPath[i].lng + '</li>';
		output += '<li>' + 'lat:' + newPath[i].lat + '</li>';
		output += '<li>' + 'elevation:' + newPath[i].elevation + ' meters'
				+ '</li>';
		output += '</ul>';
	}
	jsonStringWithElevation = JSON.stringify(newPath);
	output += '<li>';
	output += 'jsonString:';
	output += '<li>';
	output += jsonString;
	output += '</li>';
	output += '</li>';

	output += '<li>';
	output += 'jsonStringWithElevation:';
	output += '<li>';
	output += jsonStringWithElevation;
	output += '</li>';
	output += '</li>';
	
	output += '<li>';
	output += 'elevation:';
	output += '<li>';
	output += getElevation();
	output += '</li>';
	output += '</li>';
	
	output += '<li>';
	output += 'elevation Path:';
	output += '<li>';
	output += getElevationPath();
	output += '</li>';
	output += '</li>';
	
	output += '<li>';
	output += 'roads Path:';
	output += '<li>';
	output += roadsPath;
	output += '</li>';
	output += '</li>';
	
	var update = document.getElementById('links');
	update.innerHTML = output;
	join_jsonServices('JSON/american_road_trip.json', 'JSON/route101.json')
}
window.onload = out;

function join_jsonServices(json1, json2) {
	$.getJSON(json1, function(info) {
		$.getJSON(json2, function(info1) {
			Array.prototype.push.apply(info.services, info1.vehicles[0].start_address);
			Array.prototype.push.apply(info.services, info1.services);
			finalObj = info;
		});
	});
}

function mergeJSON(source1, source2) {
	/*
	 * Properties from the Souce1 object will be copied to Source2 Object. Note:
	 * This method will return a new merged object, Source1 and Source2 original
	 * values will not be replaced.
	 */
	var mergedJSON = Object.create(source2);// Copying Source2 to a new Object

	for ( var attrname in source1) {
		if (mergedJSON.hasOwnProperty(attrname)) {
			if (source1[attrname] != null
					&& source1[attrname].constructor == Object) {
				/*
				 * Recursive call if the property is an object, Iterate the
				 * object and set all properties of the inner object.
				 */
				mergedJSON[attrname] = mergeJSON(source1[attrname],
						mergedJSON[attrname]);
			}

		} else {// else copy the property from source1
			mergedJSON[attrname] = source1[attrname];

		}
	}

	return mergedJSON;
}


function sendSpeedLimitRequest(requestIndex) {
apiKey = "AIzaSyDAzlSv9_pOZbE9glz_2agKI97xbSdvKQ4";
    $.ajax({
        url: 'https://roads.googleapis.com/v1/speedLimits?key=' + apiKey + speedLimitRequests[requestIndex] + '&units=KPH',
        type: 'get',
        async: true,
        dataType: "json",
        success: function(speedLimitResponse) {

            if (!jQuery.isEmptyObject(speedLimitResponse)) {

                blnAnySpeedLimits = true;

                for (i = 0; i < speedLimitResponse.speedLimits.length; i++) {
                    placeIds[speedLimitResponse.speedLimits[i].placeId.toString()].speedLimit = parseFloat(speedLimitResponse.speedLimits[i].speedLimit);
                }
                //advance the counter and send the next speed limit request
                requestIndex++;
                updateMessage("Sending Speed Limit request: " + (requestIndex) + " of " + Object.keys(speedLimitRequests).length);

                if (requestIndex < Object.keys(speedLimitRequests).length) {
                    sendSpeedLimitRequest(requestIndex);
                } else {
                    //when all the speed limits are returned not draw the results
                    addSnappedPointsToMap();
                }
            }else{
                blnAnySpeedLimits = false;
                addSnappedPointsToMap();
            }

        },
        error: function(xhr) {
            //Do Something to handle error
            alert("Error getting Roads API speed limits: " + xhr.toString());
        }
    });

}
