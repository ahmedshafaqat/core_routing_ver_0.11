/**
 * Copyright (c) 2013-2014 TomTom International B.V. All rights reserved.
 */

/**
 *  Get Cookie with unescaped value
 */
function getCookie(c_name) {
	var c_value = document.cookie;
	var c_start = c_value.indexOf(" " + c_name + "=");
	if (c_start == -1) {
		c_start = c_value.indexOf(c_name + "=");
	}
	if (c_start == -1) {
		c_value = null;
	} else {
		c_start = c_value.indexOf("=", c_start) + 1;
		var c_end = c_value.indexOf(";", c_start);
		if (c_end == -1) {
			c_end = c_value.length;
		}
		c_value = unescape(c_value.substring(c_start, c_end));
	}
	return c_value;
}
/**
 *  Set Cookie with escaped value
 */
function setCookie(c_name, value, expDays) {
	var expDate = new Date();
	expDate.setDate(expDate.getDate() + expDays);
	var c_value = escape(value) + ((expDays == null) ? "" : "; secure=true; expires=" + expDate.toUTCString());
	document.cookie = c_name + "=" + c_value;
}

/**
 *  Places cursor on the second form element.
 *  Function for first form element exist in auth.js
 */
function placeCursorOnSecondElm() {
	var field = document.getElementById("IDToken2");
	if (field) {
		field.focus();
	}
}