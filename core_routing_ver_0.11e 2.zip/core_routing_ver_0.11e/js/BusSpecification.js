function bus_identifaction(rego){
    
    this.rego = rego;
    // Next iterartion will have folling attributes
    /* this.fleet_no = fleet_no; //exapmple 0001 data format intiger
       this.rego_due = rego_due  //  example 01/12/2016 data type Date
       this.complance_date = complance_date // 02/02/2017 next inspection date
       */  
    
    
}


function bus_specification(m,n,bm,bs,mp){
/* m = mass of the bus without battery and passengerload
 * n= number passenger 

*/
var mass = 9800.00; //default BYD 350 buss net mass
if(m != null && m > 0){
    mass = n;
} 
var number_pax = 1; //default emplty bus still have driver to driver
if(n != null && n > 1 && n < 57)
{
    number_pax = n;
}
else { return window.alert("invalid number ot out of range"); }// maximum pax number is 57

var battery_mass = 4000;// standard 140KW battery pack ways 4000kg and default size
  
if (bm > 100){
battery_mass = bm;
}

var battery_storage  = 144000;

if(bs >100){
   battery_storage = bm;
}
var electric_motor = 110;//Default motor powet 110KW
    if (mp>20){
        electric_motor = mp;
    }

// All the return functions either default value or inserted value

function total_bus_mass(){
    
    var total_mass =  mass + ( number_pax * 65.00 ) + battery_mass ; 
    return total_mass;
}
// Most the lithium-ion or poymer battery can discharge upto 80% without damaging battery
function battery_max_capacity() {
     var max_capacity = battery_storage * 0.8;
}
//While operation battery will charg quickly to 90% but last 10 % only can be 
//achived via overnight trikle charging

function battery_running_capacity() {
    var running_capacity = battery_storage * 0.7;
}

function motor_power()
{
    return electric_motor;
}
function available_force_moving(eh,cs){
    var elevation_height = 0;
    var current_speed = 0;
if (eh != null ){elevation_height = eh ;}
if (cs != null){current_speed = cs;}
    // Potential Force is going to be Fp= m*g*h;
    // Kientic Force is going to be Fk=0.5 * m * v^2;
    // Motor Force in this electric_motor Fe;
     var g = 9.8;//Constant & gravity
     var m = (total_bus_mass());

     var Fp = m * g * elevation_height;
     var Fk = 0.5 * m * current_speed^2
     var Fe = electric_motor(); 
     
    var total_available_force = Fp+Fe+Fk;
    
    return total_available_force; 
    
    
}







}
